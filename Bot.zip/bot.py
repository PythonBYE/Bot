from PIL import Image, ImageDraw, ImageFont
from aiogram import Bot, Dispatcher, executor, types
import logging
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import InputFile
from random import randint

API_TOKEN = '1792022606:AAGNCBcTtztgdux_HYDwOiFzP0zaBZ11YXA'

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())


class Form(StatesGroup):
    user_input = State()


keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
keyboard.add('Сделать скриншот')


@dp.message_handler(lambda message: message.chat.type == "private", commands=['start'])
async def start_bot(message: types.Message):
    await message.answer(f"Привет, {message.chat.first_name}! В этом боте можно сделать скриншот, внизу появилась "
                         f"кнопка.",
                         reply_markup=keyboard)


@dp.message_handler(lambda message: message.chat.type == "private", text='Сделать скриншот')
async def start_bot(message: types.Message):
    await message.answer(f"Отправьте следующее сообщение в таком формате:\n"
                         f"1. Время\n"
                         f"2. Баланс (только цифры)\n"
                         f"3. Дата платежа\n"
                         f"4. Наименование покупки\n"
                         f"5. Сумма платежа (только цифры)\n"
                         f"6. Последние 4 цифры карты\n\n"
                         f"Пример:\n"
                         f"`17:49`\n"
                         f"`30000,00`\n"
                         f"`3 сентября 2020, 13:21`\n"
                         f"`Различные товары`\n"
                         f"`1000`\n"
                         f"`1393`",
                         reply_markup=keyboard, parse_mode='Markdown')
    await Form.user_input.set()


@dp.message_handler(state=Form.user_input, content_types=types.ContentTypes.TEXT)
async def get_work_experience(message: types.Message, state: FSMContext):
    user_input = message.text.split('\n')
    if len(user_input) < 6:
        await message.answer('Вы отправили сообщение в неверном формате!')
    else:
        with Image.open('screen.jpg') as im:
            width, height = im.size
            font_time = ImageFont.truetype('arial.ttf', size=22)
            font_cash = ImageFont.truetype('arialbd.ttf', size=26)
            font_date = ImageFont.truetype('arial.ttf', size=30)
            font_item = ImageFont.truetype('arialbd.ttf', size=25)
            font_count = ImageFont.truetype('arial.ttf', size=65)
            font_numbers = ImageFont.truetype('arial.ttf', size=32)

            draw_text = ImageDraw.Draw(im)
            msg = user_input[0]
            w, h = draw_text.textsize(msg, font_item)
            draw_text.text(
                ((width - w) / 2, 10),
                msg,
                align='center',
                # Добавляем шрифт к изображению
                font=font_time,
                fill='#ffffff')
            msg = user_input[1] + ' €'
            w, h = draw_text.textsize(msg, font_item)
            draw_text.text(
                ((width - w) / 2, 85),
                msg,
                align='center',
                # Добавляем шрифт к изображению
                font=font_cash,
                fill='#404040')
            msg = user_input[2]
            w, h = draw_text.textsize(msg, font_date)
            draw_text.text(
                ((width - w) / 2, 220),
                msg,
                align='center',
                # Добавляем шрифт к изображению
                font=font_date,
                fill='#717274')

            msg = user_input[3]
            w, h = draw_text.textsize(msg, font_item)
            draw_text.text(
                ((width - w) / 2, 535),
                msg,
                align='center',
                # Добавляем шрифт к изображению
                font=font_item,
                fill='#717274')

            msg = '- ' + user_input[4] + ' €'
            w, h = draw_text.textsize(msg, font_count)
            draw_text.text(
                ((width - w) / 2, 580),
                msg,
                align='left',
                # Добавляем шрифт к изображению
                font=font_count,
                fill='#ffffff')

            msg = user_input[5]
            w, h = draw_text.textsize(msg, font_numbers)
            draw_text.text(
                ((width - w) / 2 + w, height - 192),
                msg,
                align='center',
                # Добавляем шрифт к изображению
                font=font_numbers,
                fill='#ffffff')
            file_name = 'result.jpg'
            im.save(file_name)
            await message.answer_photo(InputFile(file_name))
            await state.finish()


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)